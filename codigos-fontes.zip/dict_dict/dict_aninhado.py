import os
import conteudo as sub
os.system("cls")
# SUBALGORITMOS



# Dicionário de dicionário (níveis)
pessoa = {
    "Edson":{
        "nomepai": "Jurandir",
        "nomemae": "Ester",
        "irmao": "Edilson",
    },
    "Marcelo":{
        "nomepai": "Antonio",
        "nomemae": "Maria",
        "irmao": "Adriano",
    }
}

# Exibindo os dados
for k1, v1 in pessoa.items():
    print(f"Nome: {k1}")
    for k2, v2 in v1.items():
        print(f"\t{k2}: {v2}")

pessoa2 = {
    "Edson":{
        "nomepai": "Jurandir",
        "nomemae": "Ester",
        "irmaos": {
            "irmao1":"Edilson",
            "irmao2":"Elaine",
        }
    },
    "Marcelo":{
        "nomepai": "Antonio",
        "nomemae": "Maria",
        "irmaos": {
            "irmao1": "Adriano",
            "irmao2": "Samuel",
            "irmao3": "Carla",
        }
    }
}

# Exibindo os dados de forma falha
os.system("cls")
for k1, v1 in pessoa2.items():
    print(f"Nome: {k1}")
    for k2, v2 in v1.items():
        print(f"\t{k2}: {v2}")

# Exibir o dicionario de forma correta
os.system("cls")
sub.exibe_dados(pessoa2)

# Criando uma key nivel 1
'''

usuario = input("Pessoa: ")

if key_existe(pessoa2, usuario): # se existir
    chave = input("Nova chave: ")
    conteudo = input("Conteudo: ")
    pessoa2[usuario][chave] = conteudo
else:
    print("Pessoa nao existe!")

exibe_dados(pessoa2)

'''

# Criando uma key nível 2
"""
chave = input("Novo chave: ")
nome_irmao = input("Nome irmão: ")

pessoa2["Edson"]["irmaos"][chave] = nome_irmao

exibe_dados(pessoa2)
"""

os.system("cls")
sub.exibe_dados(pessoa2)
while True:
    nome_irmao = input("Nome irmão: ")
    if nome_irmao != "":
        numero = len(pessoa2["Edson"]["irmaos"]) + 1
        chave = f"irmao{numero}"
        pessoa2["Edson"]["irmaos"][chave] = nome_irmao
        sub.exibe_dados(pessoa2)
    else:
        break


os.system("cls")
sub.exibe_dados(pessoa2)
nome = input("nome do usuario: ")
pessoa2 = sub.adicionar_pessoa(pessoa2, nome)
pessoa2[nome]["nomepai"] = input("nome do pai: ")
pessoa2[nome]["nomemae"] = input("nome da mae: ")

irmao = []
nome_irmao = ""
while True: 
    nome_irmao = input("digite o nome do seu irmao 0 para finalizar: ")
    if nome_irmao == 0:
        break
    else:

        irmao.append(nome_irmao)
        continue

sub.exibe_dados(pessoa2)
