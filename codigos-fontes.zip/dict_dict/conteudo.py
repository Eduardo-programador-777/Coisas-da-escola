import os

# SUBALGORITMOS
os.system("cls")
def exibe_dados(_p: dict) -> None:
    for _k1, _v1 in _p.items():
        print(f"Nome: {_k1}")
        for _k2, _v2 in _v1.items():
            if isinstance(_v2, dict): # se for um dicionario
                # tratar como dicionario - Particionar as informacoes
                print(f"\t{_k2}")
                for _k3, _v3 in _v2.items():
                    print(f"\t\t{_k3}: {_v3}")
            else:
                # tratar como um outro dado (simples)
                print(f"\t{_k2}: {_v2}")

def key_existe(_p: dict, _k: str) -> bool:
    return _k in _p
def adicionar_pai(_p:dict, _nome, _nomepai):
    _p[_nome]["nomepai"] = _nomepai
    return _p
def adicionar_mae(_p:dict, _nome, _nomemae):
    _p[_nome]["nomemae"] = _nomemae
    return _p

def adicionar_pessoa(_p: dict, _nomePessoa: str, _nomepai, _nomemae, _irmao)-> dict : 
    if key_existe(_p, _nomePessoa):
        print("Essa pessoa ja existe!")
    else:
        
        _p[_nomePessoa] = {
        "nomepai": adicionar_pai(_p, _nomePessoa, _nomepai),
        "nomemae": adicionar_mae(_p, _nomePessoa, _nomemae),
        "irmaos": ""
        }
        _numero = len(_irmao)

        for _i in range(_i, _numero, 1):
            _chave = f"irmao{_numero}"
            _p["Edson"]["irmaos"][_chave] = _irmao[_numero]
    return _p

