def x(n):
    if n < 4:
        print ("reprovado")
        return
    
    if n < 6:
        print("exame")
        return
    
    if n < 10:
        print("aprovado")
        return


nota = 7
x(nota)